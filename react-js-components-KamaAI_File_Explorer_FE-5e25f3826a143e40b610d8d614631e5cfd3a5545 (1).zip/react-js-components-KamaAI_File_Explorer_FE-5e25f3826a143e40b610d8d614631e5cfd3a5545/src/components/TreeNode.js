import React, { useState, useRef } from "react";
import { useDrag, useDrop } from "react-dnd";

const TreeNode = ({ node, fullPath, onFolderClick, onMoveNode, currentPath }) => {
  const [expanded, setExpanded] = useState(false);
  const [contextMenu, setContextMenu] = useState({ visible: false, x: 0, y: 0 });
  const contextMenuRef = useRef(null);

  const currentFullPath = fullPath ? `${fullPath}/${node.name}` : node.name;

  const [{ isDragging }, drag] = useDrag(() => ({
    type: "file",
    item: { node, fullPath: currentFullPath },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  }), [node, currentFullPath]);

  const [{ isOver }, drop] = useDrop(() => ({
    accept: "file",
    drop: (item) => {
      if (node.type === "folder") {
        const targetPath = currentFullPath;
        onMoveNode(item, { path: targetPath, name: node.name });
      }
    },
    collect: (monitor) => ({
      isOver: monitor.isOver(),
    }),
  }), [onMoveNode, node, currentFullPath]);

  const hasChildren = node.children && node.children.length > 0;

  const toggleExpand = () => {
    if (node.type === "folder") {
      setExpanded(!expanded);
    }
  };

  const getIcon = (type, expanded) => {
    if (type === "folder") {
      return expanded ? "📂" : "📁";
    } else {
      return "📄";
    }
  };

  const handleContextMenu = (event) => {
    event.preventDefault();
    setContextMenu({
      visible: true,
      x: event.clientX,
      y: event.clientY,
    });
  };

  const handlePaste = () => {
    const currentFullPath = fullPath ? `${fullPath}/${node.name}` : node.name;
    console.log("NODE ", node)
    // onMoveNode(currentFullPath);
    // Implement the paste functionality here
    setContextMenu({ ...contextMenu, visible: false });
  };

  const handleClickOutside = (event) => {
    if (contextMenuRef.current && !contextMenuRef.current.contains(event.target)) {
      setContextMenu({ ...contextMenu, visible: false });
    }
  };

  React.useEffect(() => {
    document.addEventListener("click", handleClickOutside);
    return () => {
      document.removeEventListener("click", handleClickOutside);
    };
  }, []);

  return (
    <div
      ref={drag}
      className="node"
      style={{ opacity: isDragging ? 0.5 : 1 }}
      onContextMenu={handleContextMenu}
    >
      <div
        ref={drop}
        className="node-name"
        onClick={() => {
          toggleExpand();
          onFolderClick(node);
        }}
        style={{ backgroundColor: isOver ? 'lightblue' : 'transparent' }}
      >
        {node.type === "folder" && (
          <span className="folder-arrow">
            {expanded ? "▼" : "▶"}
          </span>
        )}
        {getIcon(node.type, expanded)} {node.name}
      </div>
      {expanded && hasChildren && (
        <div className="node-children">
          {node.children.map((child, index) => (
            <TreeNode
              key={index}
              node={child}
              fullPath={currentFullPath}
              onFolderClick={onFolderClick}
              onMoveNode={onMoveNode}
              currentPath={currentPath}
            />
          ))}
        </div>
      )}
      {contextMenu.visible && (
        <div
          ref={contextMenuRef}
          className="context-menu"
          style={{
            position: 'absolute',
            top: contextMenu.y,
            left: contextMenu.x,
            backgroundColor: 'white',
            border: '1px solid gray',
            zIndex: 1000,
          }}
        >
          <div className="context-menu-item" onClick={handlePaste}>Paste</div>
        </div>
      )}
    </div>
  );
};

export default TreeNode;
