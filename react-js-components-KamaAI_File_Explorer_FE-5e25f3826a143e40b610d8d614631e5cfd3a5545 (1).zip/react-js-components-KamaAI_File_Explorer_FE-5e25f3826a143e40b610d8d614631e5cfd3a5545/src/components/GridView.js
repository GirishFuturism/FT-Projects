import React, { useEffect, useState, useRef } from 'react';
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faFolder, faFile, faCheck } from "@fortawesome/free-solid-svg-icons";
import { useDrag, useDrop } from "react-dnd";
import SelectionOptions from "./SelectionOptions";
import "./GridView.css";

const GridItem = ({ file, currentPath, selectedItems, toggleSelectItem, onContextMenu, handleFolderClick }) => {
  const fullPath = currentPath.map((node) => node.name).join('/') + '/' + file.name;
  const [{ isDragging }, drag] = useDrag(() => ({
    type: "file",
    item: { node: file, fullPath },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  }), [file, fullPath]);

  return (
    <div key={file.name} ref={drag} className={`grid-item ${selectedItems.includes(file) ? 'selected' : ''}`} 
         onContextMenu={(e) => onContextMenu(e, file)} style={{ opacity: isDragging ? 0.5 : 1 }}>
      <div className="select-icon" onClick={(e) => toggleSelectItem(file, e)}>
        {selectedItems.includes(file) ? 
          <FontAwesomeIcon icon={faCheck} className="check-icon" /> : 
          <div className="empty-check-icon" />}
      </div>
      <div className="grid-icon-container" onClick={() => file.type === "folder" && handleFolderClick(file, true)}>
        <FontAwesomeIcon
          icon={file.type === "folder" ? faFolder : faFile}
          size="3x"
          className="grid-icon"
        />
      </div>
      <span className="grid-item-name">{file.name}</span>
    </div>
  );
};

const GridView = ({ files, onFolderClick, currentPath, onContextMenu, handleCloseContextMenu, cutItem, copiedItem }) => {
  const [{ isOver }, drop] = useDrop({
    accept: "file",
    drop: (item) => {
      const sourcePath = item.fullPath;
      const targetPath = currentPath.map((p) => p.name).join("/");
      if (sourcePath !== targetPath) {
        console.log("Move from", sourcePath, "to", targetPath);
      }
    },
    collect: (monitor) => ({
      isOver: monitor.isOver(),
    }),
  });

  const [selectedItems, setSelectedItems] = useState([]);
  const selectionOptionsRef = useRef(null);  // Reference to the SelectionOptions component

  const toggleSelectItem = (item, e) => {
    e.stopPropagation();
    if (selectedItems.includes(item)) {
      setSelectedItems(selectedItems.filter(selectedItem => selectedItem !== item));
    } else {
      setSelectedItems([...selectedItems, item]);
    }
  };

  const handleFolderClick = (file, clearSelection = false) => {
    onFolderClick(file);
    if (clearSelection) {
      setSelectedItems([]);
    }
  };

  const renderGridItems = (items) => {
    return items.map((file, index) => (
      <GridItem
        key={index}
        file={file}
        currentPath={currentPath}
        selectedItems={selectedItems}
        toggleSelectItem={toggleSelectItem}
        onContextMenu={onContextMenu}
        handleFolderClick={handleFolderClick}
      />
    ));
  };

  const firstSelectedItemName = selectedItems.length > 0 ? selectedItems[0].name : files[0]?.name;
  const fullPath = currentPath.map((node) => node.name).join('/') + '/' + firstSelectedItemName;

  const handleSelectOption = (option) => {
    handleCloseContextMenu(option, fullPath);
    
    setSelectedItems([]);
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        !event.target.closest('.grid-item') &&
        !event.target.closest('.selection-options')  // Check if the click is inside SelectionOptions
      ) {
        setSelectedItems([]);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div>
      <SelectionOptions 
        ref={selectionOptionsRef} 
        numSelected={selectedItems.length} 
        onSelectOption={handleSelectOption} 
        cutItem={cutItem} 
        copiedItem={copiedItem} 
      />
      <div ref={drop} className="grid-container" style={{ backgroundColor: isOver ? 'lightblue' : 'transparent' }}>
        {renderGridItems(files)}
      </div>
    </div>
  );
};

export default GridView;
