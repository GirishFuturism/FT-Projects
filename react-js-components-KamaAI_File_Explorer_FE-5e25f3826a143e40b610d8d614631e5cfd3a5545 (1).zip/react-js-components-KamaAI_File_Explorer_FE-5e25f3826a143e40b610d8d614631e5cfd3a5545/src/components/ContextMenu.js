import React from "react";

const ContextMenu = ({ mouseX, mouseY, onClose, onCopy, onMove, onDelete }) => {
  return (
    <ul
      className="context-menu"
      style={{
        top: mouseY,
        left: mouseX,
        position: "absolute",
        backgroundColor: "white",
        border: "1px solid black",
        padding: "10px",
        listStyle: "none",
      }}
      onMouseLeave={onClose}
    >
      <li onClick={onCopy}>Copy</li>
      <li onClick={onMove}>Move</li>
      <li onClick={onDelete}>Delete</li>
    </ul>
  );
};

export default ContextMenu;
