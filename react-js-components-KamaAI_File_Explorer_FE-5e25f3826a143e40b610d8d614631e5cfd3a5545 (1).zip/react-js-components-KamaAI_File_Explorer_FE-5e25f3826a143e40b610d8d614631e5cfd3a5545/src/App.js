import React, { useState, useEffect } from "react";
import axios from "axios";
import "./App.css";
import TreeNode from "./components/TreeNode";
import GridView from "./components/GridView";
import { DndProvider } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";

const App = () => {
  const [fileStructure, setFileStructure] = useState([]);
  const [currentFiles, setCurrentFiles] = useState([]);
  const [currentPath, setCurrentPath] = useState([]);
  const [contextMenu, setContextMenu] = useState(null);
  const [cutItem, setCutItem] = useState(null);
  const [copiedItem, setCopiedItem] = useState(null);

  const fetchFolderStructure = async () => {
    try {
      const response = await axios.get(
        "http://localhost:3001/api/folderStructure"
      );
      setFileStructure(response.data);
      setCurrentFiles(response.data); // Show the root structure initially
    } catch (error) {
      console.error("Error fetching folder structure:", error);
    }
  };

  useEffect(() => {
    fetchFolderStructure();
  }, []);

  const handleContextMenu = (e, node) => {
    e.preventDefault();
    setContextMenu({
      mouseX: e.clientX - 2,
      mouseY: e.clientY - 4,
    });
  };

  const handleCloseContextMenu = (value, fullPath) => {
    switch (value) {
      case 'delete':
        if (window.confirm('Are you sure you want to delete?')) handleDelete(fullPath);
        break;
      case 'rename':
        handleRename1(value, fullPath);
        break;
      case 'createFolder':
        handleCreateFolder(fullPath);
        break;
      case 'cut':
        handleCut(fullPath);
        break;
      case 'copy':
        handleCopy(fullPath);
        break;
      case 'paste':
        handlePaste();
        break;
      default:
        console.log('No case');
    }
    setContextMenu(null);
  };
  
  const handleCut = (fullPath) => {
    setCutItem(fullPath);
    setCopiedItem(null); // Clear copied item if any
  };
  
  const handleCopy = (fullPath) => {
    setCopiedItem(fullPath);
    setCutItem(null); // Clear cut item if any
  };
  
  const handlePaste = async () => {
    try {
      const targetPath = currentPath.map((node) => node.name).join('/');
      if (cutItem) {
        await axios.post('http://localhost:3001/api/move', {
          sourcePath: cutItem,
          targetPath
        });
        setCutItem(null); // Clear cut item after paste
      } else if (copiedItem) {
        await axios.post('http://localhost:3001/api/copy', {
          sourcePath: copiedItem,
          targetPath
        });
        setCopiedItem(null); // Clear copied item after paste
      }
      fetchFolderStructure();
    } catch (error) {
      console.error('Error pasting item:', error);
    }
  };

  const handleCreateFolder = async (fullPath) => {
    const newPath =
      currentPath.map((node) => node.name).join("/");
    const folderName = prompt("Enter folder name:");
    if (folderName) {
      try {
   
        const response = await axios.post('http://localhost:3001/api/createFolder', {
          parentPath: newPath,
          folderName
        });
        alert(response.data.message);
        if (response.status === 201) {
        
          // Update the state to reflect the new folder
          fetchFolderStructure();
        }
      } catch (error) {
        alert("Folder Alreay Exist");
        console.error("Error creating folder:", error);
      }
    }
  };


  const handleRename1 = async (value, fullPath) => {
    const newName = prompt("Enter new name:");
    const newPath =
      currentPath.map((node) => node.name).join("/") + "/" + newName;
    const modifiedPath = fullPath.replace(/^common\//, "");
    const modifiedNewPath = newPath.replace(/^common\//, "");
    handleRename(modifiedPath, modifiedNewPath);
  };

  const handleRename = async (oldPath, newPath) => {
    try {
      const response = await axios.post("http://localhost:3001/api/rename", {
        oldPath,
        newPath,
      });
      fetchFolderStructure();
    } catch (error) {
      console.error("Error renaming item:", error);
    }
  };
  const handleDelete = async (item) => {
    try {
      const modifiedPath = item.replace(/\\/g, "/").replace("common", "/");
      await axios.post("http://localhost:3001/api/delete", {
        path: modifiedPath,
      });
      fetchFolderStructure();
    } catch (error) {
      console.error("Error deleting item:", error);
    }
  };

  const handleFolderClick = (node) => {
    // Check if the clicked folder is already in the current path
    const folderIndex = currentPath.findIndex(
      (pathNode) => pathNode.name === node.name
    );
    if (folderIndex !== -1) {
      // If the clicked folder is already in the path, truncate the path at the index and set the files accordingly
      const newPath = currentPath.slice(0, folderIndex + 1);
      setCurrentFiles(node.children);
      setCurrentPath(newPath);
    } else {
      // Find the full path from the root to the clicked node
      const root = { name: "common", children: fileStructure }; // Explicitly define the root
      const fullPath = findFullPath(node, root.children, [root]);

      if (fullPath) {
        setCurrentFiles(node.children);
        setCurrentPath(fullPath);
      }
    }
  };

  // Helper function to find the full path from the root to the target node
  const findFullPath = (targetNode, nodes, path = []) => {
    for (const node of nodes) {
      const currentPath = [...path, node];

      if (node === targetNode) {
        return currentPath;
      }

      if (node.children) {
        const result = findFullPath(targetNode, node.children, currentPath);

        if (result) {
          return result;
        }
      }
    }

    return null;
  };

  const handleBreadcrumbClick = (index) => {
    if (index === 0) {
      setCurrentFiles(fileStructure);
      setCurrentPath([]);
    } else {
      const newPath = currentPath.slice(0, index);
      setCurrentFiles(newPath[newPath.length - 1].children);
      setCurrentPath(newPath);
    }
  };

  const renderBreadcrumbs = () => {
    return currentPath.map((node, index) => (
      <span
        key={index}
        onClick={() => handleBreadcrumbClick(index + 1)}
        className="breadcrumb"
      >
        {node.name}
        {index < currentPath.length - 1 && " > "}
      </span>
    ));
  };

  const handleMoveNode = async (sourceNode, targetNode) => {
    try {
      // Remove 'common/' from the start of sourcePath and 'root/' from the start of targetPath
      const sourcePath = sourceNode.fullPath;
      const targetPath = targetNode.path;
      await axios.post("http://localhost:3001/api/move", {
        sourcePath,
        targetPath,
      });
      fetchFolderStructure();
    } catch (error) {
      console.error("Error moving node:", error);
    }
  };
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (!event.target.closest('.grid-item')) {
        setContextMenu(null);
      }
    };
 
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
  return (
    <DndProvider backend={HTML5Backend}>
      <div className="container">
        <div className="panel-left">
          {fileStructure.length > 0 && (
            <TreeNode
              node={{
                name: "common",
                path: "",
                type: "folder",
                children: fileStructure,
              }}
              fullPath=""
              onContextMenu={handleContextMenu}
              onFolderClick={handleFolderClick}
              onMoveNode={handleMoveNode}
              currentPath={currentPath}
            />
          )}
        </div>
        <div className="panel-right">
          <div className="breadcrumb-container">{renderBreadcrumbs()}</div>
          <GridView
            node={{
              name: "root",
              path: "",
              type: "folder",
              children: fileStructure,
            }}
            files={currentFiles}
            onFolderClick={handleFolderClick}
            currentPath={currentPath}
            onContextMenu={handleContextMenu}
            onMoveNode={handleMoveNode}
            handleCloseContextMenu={handleCloseContextMenu}
            cutItem={cutItem}
            copiedItem={copiedItem}
          />
        </div>
      </div>
      {contextMenu && (
        <div
          style={{
            position: "absolute",
            top: contextMenu.mouseY,
            left: contextMenu.mouseX,
            backgroundColor: "white",
            border: "1px solid #ccc",
            zIndex: 1000,
          }}
          onClick={handleCloseContextMenu}
        >
          <div onClick={() => handleCloseContextMenu("copy")}>Copy</div>
          <div onClick={() => handleCloseContextMenu("delete")}>Delete</div>
          <div onClick={handleCloseContextMenu}>Paste</div>
          <div onClick={handleCloseContextMenu}>Move</div>
        </div>
      )}
    </DndProvider>
  );
};

export default App;
