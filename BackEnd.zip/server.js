const express = require("express");
const cors = require("cors");
const path = require("path");
const fs = require("fs");
 
const app = express();
const PORT = 3001;
 
app.use(cors());
app.use(express.json());
 
const COMMON_FOLDER_PATH = path.join(__dirname, "common");
 
const getFolderStructure = (dirPath) => {
  const structure = [];
  const items = fs.readdirSync(dirPath);
 
  items.forEach((item) => {
    const itemPath = path.join(dirPath, item);
    const stats = fs.statSync(itemPath);
 
    if (stats.isDirectory()) {
      structure.push({
        name: item,
        type: "folder",
        children: getFolderStructure(itemPath),
      });
    } else {
      structure.push({
        name: item,
        type: "file",
      });
    }
  });
 
  return structure;
};
 
app.get("/api/folderStructure", (req, res) => {
  const structure = getFolderStructure(COMMON_FOLDER_PATH);
  res.json(structure);
});
 
// Add this to your existing Node.js server code
 
app.post("/api/rename", (req, res) => {
  const { oldPath, newPath } = req.body;
  console.log("1st item renamed");
 
  try {
    const absoluteOldPath = path.join(COMMON_FOLDER_PATH, oldPath);
    const absoluteNewPath = path.join(COMMON_FOLDER_PATH, newPath);
    fs.renameSync(absoluteOldPath, absoluteNewPath);
    res.json({ success: true, sourcePath: absoluteOldPath, targetPath: absoluteNewPath });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
 
app.post("/api/delete", (req, res) => {
  const { path: itemPath } = req.body;
  console.log("1st item deleted");
 
  try {
    const absolutePath = path.join(COMMON_FOLDER_PATH, itemPath);
    if (fs.lstatSync(absolutePath).isDirectory()) {
      fs.rmdirSync(absolutePath, { recursive: true });
    } else {
      fs.unlinkSync(absolutePath);
    }
    res.json({ success: true, sourcePath: absolutePath, targetPath: absolutePath });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
 
 
app.post("/api/move", (req, res) => {
  let { sourcePath, targetPath } = req.body;
  const fullPath = path.join(__dirname, sourcePath);
  // Remove the 'common/' or 'root/' prefix from the paths if present
  const cleanPath = (p) => p.replace(/^(common|root)\/?/, '');
  sourcePath = cleanPath(sourcePath);
  targetPath = cleanPath(targetPath);
  try {
    const absoluteSourcePath = path.join(COMMON_FOLDER_PATH, sourcePath);
    const absoluteTargetPath = path.join(COMMON_FOLDER_PATH, targetPath, path.basename(sourcePath));
    fs.renameSync(absoluteSourcePath, absoluteTargetPath);
    res.json({ success: true, sourcePath: absoluteSourcePath, targetPath: absoluteTargetPath});  //-------------
    console.log("move sourcePath", absoluteSourcePath);
    console.log("move targetPath", absoluteTargetPath);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});
 
// Copy paste Functionality
app.post("/api/copy", (req, res) => {
  const { sourcePath, targetPath } = req.body;
  const cleanPath = (p) => p.replace(/^(common|root)\/?/, '');
  const absoluteSourcePath = path.join(COMMON_FOLDER_PATH, cleanPath(sourcePath));
  const absoluteTargetPath = path.join(COMMON_FOLDER_PATH, cleanPath(targetPath), path.basename(sourcePath));

  try {
    const copyRecursiveSync = (src, dest) => {
      const stats = fs.statSync(src);
      if (stats.isDirectory()) {
        fs.mkdirSync(dest);
        fs.readdirSync(src).forEach((childItemName) => {
          copyRecursiveSync(path.join(src, childItemName), path.join(dest, childItemName));
        });
      } else {
        fs.copyFileSync(src, dest);
      }
    };

    copyRecursiveSync(absoluteSourcePath, absoluteTargetPath);
    res.json({ success: true, sourcePath: absoluteSourcePath, targetPath: absoluteTargetPath });
    console.log("Copy sourcePath", absoluteSourcePath);
    console.log("Copy targetPath", absoluteTargetPath);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});



// New endpoint for renaming a file or folder
app.post("/api/rename", (req, res) => {
  const { oldPath, newPath } = req.body;
  console.log("2nd item renamed");
  try {
    const cleanPath = (p) => p.replace(/^(common|root)\/?/, '');
    const sourcePath = cleanPath(oldPath);
    const targetPath = cleanPath(newPath);
    const absoluteOldPath = path.join(COMMON_FOLDER_PATH, sourcePath);
    const absoluteNewPath = path.join(path.dirname(absoluteOldPath), targetPath);

    fs.renameSync(absoluteOldPath, absoluteNewPath);

    res.json({ success: true, sourcePath: absoluteOldPath, targetPath: absoluteNewPath });
  } catch (error) {
    console.error("Error renaming item:", error);
    res.status(500).json({ error: error.message });
  }
});
 
// New endpoint for deleting a file or folder
app.post("/api/delete", (req, res) => {
  const { path: filePath } = req.body;
  console.log("2nd item deleted");
  const fullPath = path.join(ROOT_DIR, filePath);
  fs.rm(fullPath, { recursive: true, force: true }, (err) => {
    if (err) {
      console.error("Error deleting file:", err);
      return res.status(500).json({ error: "Error deleting file" });
    }
    res.json({ message: "File deleted successfully" });
  });
});

// To Create New Folder
 
app.post('/api/createFolder', (req, res) => {
  const { parentPath, folderName } = req.body;
  const cleanPath = (p) => p.replace(/^(common|root)\/?/, '');
  const basePath = cleanPath(parentPath || 'common');
  const fullPath = path.join(COMMON_FOLDER_PATH, basePath, folderName);

  console.log("Create folder base path: ", basePath);
  console.log("Create folder full path: ", fullPath);

  if (!fs.existsSync(fullPath)) {
    fs.mkdirSync(fullPath);
    res.status(201).send({ message: 'Folder created successfully', path: fullPath });
  } else {
    res.status(400).send({ message: 'Folder already exists', path: fullPath });
  }
});


 
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});