import React, { useState } from "react";
import { useDrag, useDrop } from "react-dnd";
 
const TreeNode = ({ node, onContextMenu, onMoveNode, onCopyNode }) => {
  const [expanded, setExpanded] = useState(false);
 
  const [{ isDragging }, drag] = useDrag(() => ({
    type: "file",
    item: { node },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
  }), [node]);
 
  const [{ isOver }, drop] = useDrop(() => ({
    accept: "file",
    drop: (item) => onMoveNode(item.node, node),
    collect: (monitor) => ({
      isOver: monitor.isOver(),
    }),
  }), [onMoveNode, node]);
 
  const hasChildren = node.children && node.children.length > 0;
 
  const toggleExpand = () => {
    if (node.type === "folder") {
      setExpanded(!expanded);
    }
  };
 
  const getIcon = (type, expanded) => {
    if (type === "folder") {
      return expanded ? "📂" : "📁";
    } else {
      return "📄";
    }
  };
 
  const constructPath = (parentPath, childName) => {
    return parentPath ? `${parentPath}/${childName}` : childName;
  };
 
  return (
<div ref={drag} className="node" onContextMenu={(e) => onContextMenu(e, node)} style={{ opacity: isDragging ? 0.5 : 1 }}>
<div ref={drop} className="node-name" onClick={toggleExpand} style={{ backgroundColor: isOver ? 'lightblue' : 'transparent' }}>
        {node.type === "folder" && (
<span className="folder-arrow">
            {expanded ? "▼" : "▶"}
</span>
        )}
        {getIcon(node.type, expanded)} {node.name}
</div>
      {expanded && hasChildren && (
<div className="node-children">
          {node.children.map((child, index) => (
<TreeNode
              key={index}
              node={{ ...child, path: constructPath(node.path, child.name) }}
              onContextMenu={onContextMenu}
              onMoveNode={onMoveNode}
              onCopyNode={onCopyNode}
            />
          ))}
</div>
      )}
</div>
  );
};
 
export default TreeNode;