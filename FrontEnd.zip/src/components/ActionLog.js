import React, { useState, useEffect } from "react";
import "./ActionLog.css";

const ActionLog = () => {
  const [logs, setLogs] = useState([]);

  useEffect(() => {
    const storedLogs = JSON.parse(localStorage.getItem('actionLogs')) || [];
    setLogs(storedLogs);
  }, []);

  const formatDate = (timestamp) => {
    const date = new Date(timestamp);
    return date.toLocaleString('en-IN', { timeZone: 'Asia/Kolkata' });
  };

  return (
    <div className="action-log">
      <h2>Action Log</h2>
      <table>
        <thead>
          <tr>
            <th>Action</th>
            <th>Source Path</th>
            <th>Target Path</th>
            <th>Date/Time (IST)</th>
          </tr>
        </thead>
        <tbody>
          {logs.map((log, index) => (
            <tr key={index}>
              <td>{log.action}</td>
              <td>{typeof log.path === 'object' ? log.path.sourcePath : log.path}</td>
              <td>{typeof log.path === 'object' ? log.path.targetPath : log.path}</td>
              <td>{formatDate(log.timestamp)}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default ActionLog;
