import React from 'react';
import './SelectionOptions.css';

const SelectionOptions = ({ numSelected = 0, onSelectOption, cutItem, copiedItem }) => {
  return (
    <div className="selection-options">
      <div className="options-left">
        {numSelected === 0 ? (
          <button onClick={() => onSelectOption('createFolder')}>Create New Folder</button>
        ) : (
          <>
            <button onClick={() => onSelectOption('cut')}>Cut</button>
            <button onClick={() => onSelectOption('copy')}>Copy</button>
            <button onClick={() => onSelectOption('delete')}>Delete</button>
            {/* <button onClick={() => onSelectOption('download')}>Download</button> */}
            <button onClick={() => onSelectOption('rename')}>Rename</button>
          </>
        )}
        {(cutItem || copiedItem) && (
          <button onClick={() => onSelectOption('paste')}>Paste</button>
        )}
      </div>
      <div className="options-right">
        {numSelected > 0 && <span>{numSelected} {numSelected > 1 ? 'items' : 'item'} selected</span>}
      </div>
    </div>
  );
};

export default SelectionOptions;