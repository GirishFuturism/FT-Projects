import React, { useState, useEffect } from "react";
import axios from "axios";
import "./App.css";
import TreeNode from "./components/TreeNode";
import GridView from "./components/GridView";
import { DndProvider } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";
 
const App = () => {
  const [fileStructure, setFileStructure] = useState([]);
  const [currentFiles, setCurrentFiles] = useState([]);
  const [currentPath, setCurrentPath] = useState([]);
  const [contextMenu, setContextMenu] = useState(null);
  const [cutItem, setCutItem] = useState(null);
  const [copiedItem, setCopiedItem] = useState(null);
 
  const BASE_URL = "http://localhost:3001";
 
  const fetchFolderStructure = async () => {
    try {
      const response = await axios.get(`${BASE_URL}/api/folderStructure`);
      setFileStructure(response.data);
      setCurrentFiles(response.data); // Show the root structure initially
    } catch (error) {
      console.error("Error fetching folder structure:", error);
    }
  };
 
  useEffect(() => {
    fetchFolderStructure();
  }, []);

  const savePathToLocalStorage = (action, path) => {
    const logs = JSON.parse(localStorage.getItem('actionLogs')) || [];
    const newLog = {
      action,
      path,
      timestamp: new Date().toISOString(),
    };
    logs.push(newLog);
    localStorage.setItem('actionLogs', JSON.stringify(logs));
  };
  
 
  const handleContextMenu = (e, node) => {
    e.preventDefault();
    setContextMenu({
      mouseX: e.clientX - 2,
      mouseY: e.clientY - 4,
    });
  };
 
  const handleCloseContextMenu = (value, fullPath) => {
    switch (value) {
      case 'delete':
        if (window.confirm('Are you sure you want to delete?')) handleDelete(fullPath);
        break;
      case 'rename':
        handleRename1(value, fullPath);
        break;
      case 'createFolder':
        handleCreateFolder(fullPath);
        break;
      case 'cut':
        handleCut(fullPath);
        break;
      case 'copy':
        handleCopy(fullPath);
        break;
      case 'paste':
        handlePaste();
        break;
      case 'download' : console.log("Download", fullPath);
        break;
      default:
        console.log('No case');
    }
    setContextMenu(null);
  };
 
  const handleCut = (fullPath) => {
    setCutItem(fullPath);
    setCopiedItem(null); // Clear copied item if any
    // savePathToLocalStorage('cut', fullPath);
  };
 
  const handleCopy = (fullPath) => {
    setCopiedItem(fullPath);
    setCutItem(null); // Clear cut item if any
    // savePathToLocalStorage('copy', fullPath);
  };
 
  const handlePaste = async () => {
    try {
      const targetPath = currentPath.map((node) => node.name).join('/');
      let response;
  
      if (cutItem) {
        // Move the item
        response = await axios.post(`${BASE_URL}/api/move`, {
          sourcePath: cutItem,
          targetPath
        });
        
        // Log the response to the console
        console.log("Cut Operation - Source Path:", response.data.sourcePath);
        console.log("Paste Operation - Target Path:", response.data.targetPath);
        
        // savePathToLocalStorage('cut', response.data.sourcePath);
        // savePathToLocalStorage('paste (cut)', response.data.targetPath);
        savePathToLocalStorage('cut', { sourcePath: response.data.sourcePath, targetPath: response.data.targetPath });
        setCutItem(null); // Clear cut item after paste
      } else if (copiedItem) {
        // Copy the item
        response = await axios.post(`${BASE_URL}/api/copy`, {
          sourcePath: copiedItem,
          targetPath
        });
        
        // Log the response to the console
        console.log("Copy Operation - Source Path:", response.data.sourcePath);
        console.log("Paste Operation - Target Path:", response.data.targetPath);
        
        
        // savePathToLocalStorage('copy', response.data.sourcePath);
        // savePathToLocalStorage('paste (copy)', response.data.targetPath);
        savePathToLocalStorage('copy', { sourcePath: response.data.sourcePath, targetPath: response.data.targetPath });
        setCopiedItem(null); // Clear copied item after paste
      }
  
      fetchFolderStructure();
    } catch (error) {
      console.error('Error pasting item:', error);
    }
  };
  
 
  const handleCreateFolder = async (fullPath) => {
    const newPath = currentPath.map((node) => node.name).join("/");
    const folderName = prompt("Enter folder name:");
    if (folderName) {
      try {
        const response = await axios.post(`${BASE_URL}/api/createFolder`, {
          parentPath: newPath,
          folderName
        });
        alert(response.data.message);
        if (response.status === 201) {
          console.log("Create Folder Path:", `${response.data.path}/${folderName}`); // Log the full path
          fetchFolderStructure();
          savePathToLocalStorage('createFolder', { sourcePath: response.data.path, targetPath: folderName });
        }
      } catch (error) {
        alert("Folder Already Exist");
        console.error("Error creating folder:", error);
      }
    }
  };
 
  const handleRename1 = async (value, fullPath) => {
    const newName = prompt("Enter new name:");
    const newPath =
      currentPath.map((node) => node.name).join("/") + "/" + newName;
    const modifiedPath = fullPath.replace(/^common\//, "");
    const modifiedNewPath = newPath.replace(/^common\//, "");
    handleRename(modifiedPath, modifiedNewPath);
  };
 
  const handleRename = async (oldPath, newPath) => {
    try {
      // Make the API request and capture the response
      const response = await axios.post(`${BASE_URL}/api/rename`, {
        oldPath,
        newPath,
      });
      
      // Log the response to the console
      console.log("Source Path from server For Rename:", response.data.sourcePath);
      console.log("Target Path from server For Rename:", response.data.targetPath);
      
      // Perform additional actions after successful API call
      fetchFolderStructure();
      savePathToLocalStorage('rename', { sourcePath: response.data.sourcePath, targetPath: response.data.targetPath });
    } catch (error) {
      console.error("Error renaming item:", error);
    }
  };
  
 
  const handleDelete = async (item) => {
    try {
      const modifiedPath = item.replace(/\\/g, "/").replace("common", "/");
      
      // Make the API request and capture the response
      const response = await axios.post(`${BASE_URL}/api/delete`, {
        path: modifiedPath,
      });
      
      // Log the response to the console
      console.log("Source Path from server For Delete:", response.data.sourcePath);
      console.log("Target Path from server For Delete:", response.data.targetPath);
      
      // Alert the user about the successful deletion
      alert(`File deleted successfully. Modified Path: ${modifiedPath}`);
      
      // Perform additional actions after successful API call
      fetchFolderStructure();
      savePathToLocalStorage('delete', { sourcePath: response.data.sourcePath });
    } catch (error) {
      console.error("Error deleting item:", error);
    }
  };
 
  const handleFolderClick = (node) => {
    // Check if the clicked folder is already in the current path
    const folderIndex = currentPath.findIndex(
      (pathNode) => pathNode.name === node.name
    );
    if (folderIndex !== -1) {
      // If the clicked folder is already in the path, truncate the path at the index and set the files accordingly
      const newPath = currentPath.slice(0, folderIndex + 1);
      setCurrentFiles(node.children);
      setCurrentPath(newPath);
    } else {
      // Find the full path from the root to the clicked node
      const root = { name: "common", children: fileStructure }; // Explicitly define the root
      const fullPath = findFullPath(node, root.children, [root]);
 
      if (fullPath) {
        setCurrentFiles(node.children);
        setCurrentPath(fullPath);
      }
    }
  };
 
  // Helper function to find the full path from the root to the target node
  const findFullPath = (targetNode, nodes, path = []) => {
    for (const node of nodes) {
      const currentPath = [...path, node];
 
      if (node === targetNode) {
        return currentPath;
      }
 
      if (node.children) {
        const result = findFullPath(targetNode, node.children, currentPath);
 
        if (result) {
          return result;
        }
      }
    }
 
    return null;
  };
 
  const handleBreadcrumbClick = (index) => {
    if (index === 0) {
      setCurrentFiles(fileStructure);
      setCurrentPath([]);
    } else {
      const newPath = currentPath.slice(0, index);
      setCurrentFiles(newPath[newPath.length - 1].children);
      setCurrentPath(newPath);
    }
  };
 
  const renderBreadcrumbs = () => {
    return currentPath.map((node, index) => (
      <span
        key={index}
        onClick={() => handleBreadcrumbClick(index + 1)}
        className="breadcrumb"
      >
        {node.name}
        {index < currentPath.length - 1 && " > "}
      </span>
    ));
  };
 
  const handleMoveNode = async (sourceNode, targetNode) => {
    try {
      // Remove 'common/' from the start of sourcePath and 'root/' from the start of targetPath
      const sourcePath = sourceNode.fullPath;
      const targetPath = targetNode.path;
      
      // Make the API request and capture the response
      const response = await axios.post(`${BASE_URL}/api/move`, {
        sourcePath,
        targetPath,
      });
      
      // Log the response to the console
      console.log("Source Path from server:", response.data.sourcePath);
      console.log("Target Path from server:", response.data.targetPath);
  
      // Perform additional actions after successful API call
      fetchFolderStructure();
      savePathToLocalStorage('move', { sourcePath: response.data.sourcePath, targetPath: response.data.targetPath });
    } catch (error) {
      console.error("Error moving node:", error);
    }
  };
  
 
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (!event.target.closest('.grid-item')) {
        setContextMenu(null);
      }
    };
 
    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);
 
  return (
    <DndProvider backend={HTML5Backend}>
      <div className="container">
        <div className="panel-left">
          {fileStructure.length > 0 && (
            <TreeNode
              node={{
                name: "common",
                path: "",
                type: "folder",
                children: fileStructure,
              }}
              fullPath=""
              onContextMenu={handleContextMenu}
              onFolderClick={handleFolderClick}
              onMoveNode={handleMoveNode}
              currentPath={currentPath}
            />
          )}
        </div>
        <div className="panel-right">
          <div className="breadcrumb-container">{renderBreadcrumbs()}</div>
          <GridView
            node={{
              name: "root",
              path: "",
              type: "folder",
              children: fileStructure,
            }}
            files={currentFiles}
            onFolderClick={handleFolderClick}
            currentPath={currentPath}
            onContextMenu={handleContextMenu}
            onMoveNode={handleMoveNode}
            handleCloseContextMenu={handleCloseContextMenu}
            cutItem={cutItem}
            copiedItem={copiedItem}
          />
        </div>
      </div>
      {contextMenu && (
        <div
          style={{
            position: "absolute",
            top: contextMenu.mouseY,
            left: contextMenu.mouseX,
            backgroundColor: "white",
            border: "1px solid #ccc",
            zIndex: 1000,
          }}
          onClick={handleCloseContextMenu}
        >
          <div onClick={() => handleCloseContextMenu("copy")}>Copy</div>
          <div onClick={() => handleCloseContextMenu("delete")}>Delete</div>
          <div onClick={handleCloseContextMenu}>Paste</div>
          <div onClick={handleCloseContextMenu}>Move</div>
        </div>
      )}
    </DndProvider>
  );
};
 
export default App;