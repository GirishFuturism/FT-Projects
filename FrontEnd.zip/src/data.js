// src/data.js
export const fileStructures = [
  {
    id: 1,
    name: "root",
    type: "folder",
    children: [
      {
        id: 2,
        name: "src",
        type: "folder",
        children: [
          { id: 3, name: "index.js", type: "file" },
          { id: 4, name: "App.js", type: "file" },
          {
            id: 6,
            name: "components",
            type: "folder",
            children: [
              { id: 7, name: "Header.js", type: "file" },
              { id: 8, name: "Footer.js", type: "file" },
            ],
          },
        ],
      },
      { id: 5, name: "package.json", type: "file" },
    ],
  },
];
